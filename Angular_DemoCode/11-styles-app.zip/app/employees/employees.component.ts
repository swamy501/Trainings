import { Component } from '@angular/core';

@Component({
  selector: 'my-emp',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
  styles: ['li {color: red;}']
})
export class EmployeesComponent {
  title: string = 'Employees List';
}
