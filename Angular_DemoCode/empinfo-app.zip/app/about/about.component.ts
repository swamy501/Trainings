import { Component } from '@angular/core';

@Component({
  template: '<h3>About: This application provides the employee information</h3>'
})
export class AboutComponent { }
