import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeesService } from './employees.service';

@Component({
  selector: 'my-emp',
  templateUrl: './employees.component.html'
})
export class EmployeesComponent {
  title: string = 'Employees List';
  employees: Employee[];

  constructor(private _employeesService: EmployeesService) {
  }

  ngOnInit() {
    this.getEmployees();
  }

  getEmployees() {
    this._employeesService.getEmployees().subscribe(
      (employees:any) =>  this.employees = employees,
      err => console.log(err)
    );
  }

  addEmployee() {
    this._employeesService.addEmployee().subscribe(
      (data:any) => this.getEmployees()
    );
  }

  editEmployee(empid, empname) {
    this._employeesService.editEmployee(empid, empname).subscribe(
      (data:any) => this.getEmployees()
    );
  }

  deleteEmployee(empid) {
    this._employeesService.deleteEmployee(empid).subscribe(
      (data:any) => this.getEmployees()
    );
  }

}
