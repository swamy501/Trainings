import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class EmployeesService {
    private _employeesUrl = "http://localhost:3000/employees";
    private count=100;
    private httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        })
    };

    constructor (private _http: HttpClient) { }

    getEmployees() {
        return this._http.get(this._employeesUrl);
    }

    addEmployee() {
        this.count++;
        let newEmployee = {
            "id": this.count,
            "name": "Emp-" + this.count
        }
        return this._http.post(this._employeesUrl, newEmployee, this.httpOptions);
    }

    editEmployee(empid,  empname) {
        let editEmployeeURL = `${this._employeesUrl}/${empid}`;
        let updatedEmployee = {
            "name": empname + "_U"
        }
        return this._http.put(editEmployeeURL, updatedEmployee, this.httpOptions);
    }

    deleteEmployee(empid) {
        let deleteEmployeeURL = `${this._employeesUrl}/${empid}`;
        return this._http.delete(deleteEmployeeURL);
    }
}
